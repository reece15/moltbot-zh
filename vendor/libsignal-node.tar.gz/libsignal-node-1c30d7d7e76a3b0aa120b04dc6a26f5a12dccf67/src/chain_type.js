const ChainType = {
    SENDING: 1,
    RECEIVING: 2
};

module.exports = ChainType;
